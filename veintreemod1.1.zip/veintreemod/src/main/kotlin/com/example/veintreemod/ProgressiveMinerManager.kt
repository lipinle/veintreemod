package com.example.veintreemod

import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags
import net.minecraft.ChatFormatting
import net.minecraft.core.BlockPos
import net.minecraft.network.chat.Component
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.tags.BlockTags
import net.minecraft.tags.ItemTags
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.state.BlockState
import java.util.UUID

object ProgressiveMinerManager {
    private const val MAX_CHAIN_BLOCKS = 64 // จำกัดจำนวนบล็อกสูงสุดต่อ 1 คิวเพื่อป้องกันเซิร์ฟเวอร์แลค

    enum class SkillType(val displayName: String) {
        VEINMINER("⛏ Veinminer"),
        TREE_CAPITATOR("🪓 Tree Capitator")
    }

    data class ActiveSkillState(
        val skillType: SkillType,
        val item: Item,          // ชนิดไอเท็มที่เปิดสกิลไว้ (เทียบด้วยชนิดไอเท็ม ไม่เทียบค่าความทนทาน)
        var idleTicks: Int = 0   // จำนวน tick ที่ผู้เล่นถือไอเท็มอื่นติดต่อกัน
    )

    data class BreakingTask(
        val level: ServerLevel,
        val skillType: SkillType,
        val queue: ArrayDeque<BlockPos>,
        var currentPos: BlockPos? = null,
        var progress: Float = 0f
    )

    private val activeSkills = mutableMapOf<UUID, ActiveSkillState>()
    private val breakingTasks = mutableMapOf<UUID, BreakingTask>()
    // ป้องกันการเรียกซ้ำตอนระบบสั่งทำลายบล็อกในคิว
    val internalBreakingPlayers = mutableSetOf<UUID>()

    /**
     * เปิดหรือปิดสกิลให้กับไอเท็มที่ผู้เล่นถืออยู่ในขณะนั้น
     */
    fun toggleSkillForHeldItem(player: ServerPlayer) {
        val heldStack = player.mainHandItem
        val skillType = when {
            heldStack.`is`(ItemTags.PICKAXES) -> SkillType.VEINMINER
            heldStack.`is`(ItemTags.AXES) -> SkillType.TREE_CAPITATOR
            else -> return
        }

        val current = activeSkills[player.uuid]
        if (current != null && heldStack.`is`(current.item)) {
            activeSkills.remove(player.uuid)
            cancelTask(player)
            player.displayClientMessage(
                Component.literal("${skillType.displayName} : ปิดใช้งาน").withStyle(ChatFormatting.RED),
                true
            )
        } else {
            activeSkills[player.uuid] = ActiveSkillState(skillType, heldStack.item)
            player.displayClientMessage(
                Component.literal("${skillType.displayName} : เปิดใช้งานแล้ว!").withStyle(ChatFormatting.GREEN),
                true
            )
        }
    }

    /**
     * เรียกเมื่อผู้เล่นขุดบล็อกแรกแตกด้วยตัวเอง
     */
    fun onBlockBrokenByPlayer(player: ServerPlayer, level: ServerLevel, originPos: BlockPos, originState: BlockState) {
        if (player.uuid in internalBreakingPlayers) return

        val active = activeSkills[player.uuid] ?: return
        val heldStack = player.mainHandItem

        // สกิลทำงานเฉพาะตอนถือไอเท็มที่เปิดสกิลไว้ (ถ้าถือชิ้นอื่น สกิลจะถูกปิดเองเมื่อครบเวลาใน tickIdleTimers)
        if (!heldStack.`is`(active.item)) return

        val targets: List<BlockPos> = when (active.skillType) {
            SkillType.VEINMINER -> {
                if (!isOreBlock(originState)) return
                collectConnectedBlocks(level, originPos, sortBottomToTop = false) { state ->
                    state.`is`(originState.block) // ขุดเฉพาะแร่ชนิดเดียวกันที่ติดกัน
                }
            }
            SkillType.TREE_CAPITATOR -> {
                if (!originState.`is`(BlockTags.LOGS)) return
                collectConnectedBlocks(level, originPos, sortBottomToTop = true) { state ->
                    state.`is`(BlockTags.LOGS) // ขุดท่อนไม้ที่เชื่อมต่อกันทั้งหมด
                }
            }
        }

        if (targets.isEmpty()) return

        val task = breakingTasks.getOrPut(player.uuid) {
            BreakingTask(level, active.skillType, ArrayDeque())
        }
        task.queue.addAll(targets)
    }

    /**
     * ประมวลผลการขุดทีละบล็อกในทุกๆ Server Tick
     */
    fun tick(server: MinecraftServer) {
        tickIdleTimers(server)

        val iterator = breakingTasks.iterator()
        while (iterator.hasNext()) {
            val (uuid, task) = iterator.next()
            val player = server.playerList.getPlayer(uuid)

            if (player == null || !player.isAlive) {
                iterator.remove()
                continue
            }

            // ตรวจสอบว่าผู้เล่นยังถือเครื่องมือที่ถูกต้องอยู่หรือไม่
            val heldStack = player.mainHandItem
            val validTool = when (task.skillType) {
                SkillType.VEINMINER -> heldStack.`is`(ItemTags.PICKAXES)
                SkillType.TREE_CAPITATOR -> heldStack.`is`(ItemTags.AXES)
            }

            if (!validTool) {
                clearCrackAnimation(player, task)
                iterator.remove()
                continue
            }

            // ดึงบล็อกถัดไปจากคิวถ้ายังไม่มีเป้าหมายปัจจุบัน
            if (task.currentPos == null) {
                if (task.queue.isEmpty()) {
                    iterator.remove()
                    continue
                }
                task.currentPos = task.queue.removeFirst()
                task.progress = 0f
            }

            val pos = task.currentPos!!
            val state = task.level.getBlockState(pos)

            // ข้ามหากบล็อกหายไปแล้วหรือเป็นอากาศ
            if (state.isAir || state.getDestroySpeed(task.level, pos) < 0f) {
                task.currentPos = null
                continue
            }

            // คำนวณความเร็วในการขุดต่อ 1 Tick ตามระดับของ Pickaxe/Axe และ Enchant (Efficiency)
            val delta = state.getDestroyProgress(player, task.level, pos)
            task.progress += delta

            // แสดงรอยร้าวบนบล็อกทีละขั้น (0-9) ให้เห็นภาพชัดเจน
            val crackStage = (task.progress * 10f).toInt().coerceIn(0, 9)
            task.level.destroyBlockProgress(player.id, pos, crackStage)

            // เมื่อความคืบหน้าครบ 1.0 (100%) ให้ทำลายบล็อกนั้น
            if (task.progress >= 1.0f) {
                task.level.destroyBlockProgress(player.id, pos, -1)

                internalBreakingPlayers.add(uuid)
                try {
                    // ใช้ destroyBlock ของ ServerPlayerGameMode เพื่อให้ Fortune, Silk Touch และลดความทนทานทำงานสมบูรณ์
                    player.gameMode.destroyBlock(pos)
                } finally {
                    internalBreakingPlayers.remove(uuid)
                }

                task.currentPos = null
                task.progress = 0f
            }
        }
    }

    /**
     * ระบบปิดสกิลอัตโนมัติ: ถ้าผู้เล่นถือไอเท็มอื่นติดต่อกันนานเกิน
     * [ModeSettings.IDLE_TIMEOUT_SECONDS] วินาที สกิลจะถูกปิด
     * (กลับมาถือไอเท็มเดิมก่อนครบเวลา ตัวนับจะเริ่มใหม่)
     */
    private fun tickIdleTimers(server: MinecraftServer) {
        val iterator = activeSkills.entries.iterator()
        while (iterator.hasNext()) {
            val (uuid, state) = iterator.next()
            val player = server.playerList.getPlayer(uuid)

            // ผู้เล่นออกจากเซิร์ฟเวอร์ -> เคลียร์สถานะทิ้ง
            if (player == null) {
                iterator.remove()
                continue
            }

            if (player.mainHandItem.`is`(state.item)) {
                state.idleTicks = 0
            } else if (++state.idleTicks > ModeSettings.IDLE_TIMEOUT_TICKS) {
                iterator.remove()
                cancelTask(player)
                player.displayClientMessage(
                    Component.literal(
                        "${state.skillType.displayName} : ปิดอัตโนมัติ (ถือไอเท็มอื่นเกิน ${ModeSettings.IDLE_TIMEOUT_SECONDS} วินาที)"
                    ).withStyle(ChatFormatting.RED),
                    true
                )
            }
        }
    }

    private fun isOreBlock(state: BlockState): Boolean {
        return state.`is`(ConventionalBlockTags.ORES) ||
               state.`is`(Blocks.ANCIENT_DEBRIS)
    }

    /**
     * ค้นหาบล็อกที่อยู่ติดกันแบบ 3 ทิศทาง (รวมแนวทแยง 26 ทิศทางรอบตัว) ด้วย BFS
     */
    private fun collectConnectedBlocks(
        level: ServerLevel,
        start: BlockPos,
        sortBottomToTop: Boolean,
        matcher: (BlockState) -> Boolean
    ): List<BlockPos> {
        val visited = HashSet<BlockPos>()
        val searchQueue = ArrayDeque<BlockPos>()
        val result = mutableListOf<BlockPos>()

        visited.add(start)
        searchQueue.add(start)

        while (searchQueue.isNotEmpty() && result.size < MAX_CHAIN_BLOCKS) {
            val current = searchQueue.removeFirst()

            for (dx in -1..1) {
                for (dy in -1..1) {
                    for (dz in -1..1) {
                        if (dx == 0 && dy == 0 && dz == 0) continue
                        val neighbor = current.offset(dx, dy, dz)
                        if (neighbor in visited) continue

                        visited.add(neighbor)
                        val neighborState = level.getBlockState(neighbor)
                        if (matcher(neighborState)) {
                            result.add(neighbor)
                            searchQueue.add(neighbor)
                            if (result.size >= MAX_CHAIN_BLOCKS) break
                        }
                    }
                    if (result.size >= MAX_CHAIN_BLOCKS) break
                }
                if (result.size >= MAX_CHAIN_BLOCKS) break
            }
        }

        // ถ้าเป็นต้นไม้ เรียงลำดับจากล่างขึ้นบนเพื่อให้ดูเหมือนค่อยๆ โค่นต้นไม้ทีละท่อน
        return if (sortBottomToTop) {
            result.sortedWith(compareBy({ it.y }, { it.distSqr(start) }))
        } else {
            result.sortedBy { it.distSqr(start) }
        }
    }

    private fun clearCrackAnimation(player: ServerPlayer, task: BreakingTask) {
        task.currentPos?.let { pos ->
            task.level.destroyBlockProgress(player.id, pos, -1)
        }
    }

    private fun cancelTask(player: ServerPlayer) {
        breakingTasks.remove(player.uuid)?.let { clearCrackAnimation(player, it) }
    }
}
