package com.example.veintreemod

import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
import net.minecraft.ChatFormatting
import net.minecraft.client.player.LocalPlayer
import net.minecraft.network.chat.Component
import net.minecraft.sounds.SoundEvents
import net.minecraft.sounds.SoundSource
import net.minecraft.tags.ItemTags
import net.minecraft.world.item.Item

object SneakSkillClient : ClientModInitializer {
    private const val REQUIRED_SNEAKS = 10
    private const val RESET_TIMEOUT_TICKS = 35 // รีเซ็ตหากเว้นช่วงเกิน 1.75 วินาที

    private var sneakCount = 0
    private var ticksSinceLastSneak = 0
    private var wasSneakPressed = false
    private var countingItem: Item? = null // ไอเท็มที่กำลังนับการกดย่ออยู่

    override fun onInitializeClient() {
        // โหมดแสดงผล Torch / Compass / Clock (ทำงานฝั่งไคลเอนต์ล้วนๆ)
        DisplayModeClient.init()

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            val player = client.player ?: return@register

            // นับถอยหลังรีเซ็ตจำนวนการกดหากหยุดกดกลางคัน
            if (sneakCount > 0) {
                ticksSinceLastSneak++
                if (ticksSinceLastSneak > RESET_TIMEOUT_TICKS) {
                    sneakCount = 0
                    ticksSinceLastSneak = 0
                }
            }

            val isSneakPressed = client.options.keyShift.isDown
            // ตรวจจับเฉพาะจังหวะ "เริ่มกด" (Rising Edge)
            if (isSneakPressed && !wasSneakPressed) {
                val heldItem = player.mainHandItem
                val displayMode = DisplayMode.forItem(heldItem) // คบเพลิง / เข็มทิศ / นาฬิกา
                val isSkillTool = heldItem.`is`(ItemTags.PICKAXES) || heldItem.`is`(ItemTags.AXES)

                if (displayMode != null || isSkillTool) {
                    // ถ้าสลับไปถือไอเท็มอื่นกลางคัน ให้เริ่มนับใหม่ (กันเปิดโหมดผิดชิ้น)
                    val previous = countingItem
                    if (sneakCount > 0 && previous != null && !heldItem.`is`(previous)) {
                        sneakCount = 0
                    }
                    countingItem = heldItem.item

                    sneakCount++
                    ticksSinceLastSneak = 0
                    DisplayModeClient.holdHud() // กันไม่ให้ ActionBar ของโหมดอื่นมาเขียนทับหลอดชาร์จ

                    if (sneakCount < REQUIRED_SNEAKS) {
                        // แสดงหลอดเหนือ Hotbar (ActionBar)
                        player.displayClientMessage(buildProgressBar(sneakCount, REQUIRED_SNEAKS), true)
                    } else {
                        // ครบ 10 ครั้ง: รีเซ็ตตัวนับ แล้วเปิด/ปิดโหมด
                        sneakCount = 0
                        ticksSinceLastSneak = 0

                        if (displayMode != null) {
                            // Torch / Compass / Clock: สลับโหมดในฝั่งไคลเอนต์ (มีเสียงและข้อความในตัว)
                            DisplayModeClient.toggle(player, displayMode, heldItem)
                        } else {
                            // Pickaxe / Axe: ส่ง Packet ให้เซิร์ฟเวอร์สลับสกิล
                            playDing(player, 1.6f)
                            ClientPlayNetworking.send(ActivateSkillPayload)
                        }
                    }
                }
            }
            wasSneakPressed = isSneakPressed
        }
    }

    /** เสียง "ติ้ง!" — pitch สูง = เปิด, pitch ต่ำ = ปิด */
    internal fun playDing(player: LocalPlayer, pitch: Float) {
        player.level().playSound(
            player,
            player.blockPosition(),
            SoundEvents.EXPERIENCE_ORB_PICKUP,
            SoundSource.PLAYERS,
            1.0f,
            pitch
        )
    }

    private fun buildProgressBar(current: Int, max: Int): Component {
        val filled = "■".repeat(current)
        val empty = "□".repeat(max - current)
        return Component.literal("กำลังชาร์จสกิล: [")
            .withStyle(ChatFormatting.GRAY)
            .append(Component.literal(filled).withStyle(ChatFormatting.GOLD))
            .append(Component.literal(empty).withStyle(ChatFormatting.DARK_GRAY))
            .append(Component.literal("] $current/$max").withStyle(ChatFormatting.YELLOW))
    }
}
