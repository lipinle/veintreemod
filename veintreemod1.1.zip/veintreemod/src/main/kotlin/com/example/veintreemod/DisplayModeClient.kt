package com.example.veintreemod

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.client.player.LocalPlayer
import net.minecraft.core.BlockPos
import net.minecraft.core.particles.ParticleTypes
import net.minecraft.network.chat.Component
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import kotlin.random.Random

/**
 * จัดการโหมดแสดงผลฝั่งไคลเอนต์ทั้ง 3 โหมด:
 *  - TORCH   : แสดงอนุภาคบนบล็อกที่แสงต่ำพอให้มอนสเตอร์เกิดได้ (ไม่นับแสงอาทิตย์)
 *  - COMPASS : แสดงพิกัด X/Y/Z บน ActionBar (เหนือ Hotbar)
 *  - CLOCK   : แสดงเวลาในเกมแบบดิจิทัล HH:MM บน ActionBar
 *
 * ทุกโหมดปิดเองอัตโนมัติเมื่อผู้เล่นถือไอเท็มอื่นนานเกิน [ModeSettings.IDLE_TIMEOUT_SECONDS] วินาที
 * (นับด้วยเวลาในเกม จึงหยุดนับเมื่อกดหยุดเกมในโหมดเล่นคนเดียว)
 */
object DisplayModeClient {
    private const val SCAN_INTERVAL_TICKS = 10L      // สแกนหาจุดมืดทุก 0.5 วินาที
    private const val PARTICLE_INTERVAL_TICKS = 4L   // ปล่อยอนุภาคทุก 0.2 วินาที
    private const val HUD_REFRESH_TICKS = 2L         // อัปเดตข้อความ ActionBar ทุก 0.1 วินาที
    private const val HUD_PAUSE_TICKS = 40           // พักการเขียนทับ ActionBar 2 วินาทีหลังมีข้อความแจ้งเตือน

    /** อนุภาคที่ใช้ปักหมุดจุดอันตราย — เปลี่ยนเป็นชนิดอื่นได้ที่บรรทัดนี้ */
    private val MARKER_PARTICLE = ParticleTypes.FLAME

    private class ActiveMode(val item: Item, var lastHeldTime: Long)

    private val active = LinkedHashMap<DisplayMode, ActiveMode>()
    private var lastProcessedTime = Long.MIN_VALUE
    private var hudPauseTicks = 0
    private var darkSpots: List<BlockPos> = emptyList()

    fun init() {
        ClientTickEvents.END_CLIENT_TICK.register { client -> tick(client) }
    }

    /** สลับเปิด/ปิดโหมด — เรียกเมื่อผู้เล่นกดย่อครบ 10 ครั้งขณะถือไอเท็มของโหมดนั้น */
    fun toggle(player: LocalPlayer, mode: DisplayMode, held: ItemStack) {
        val current = active[mode]
        val turnedOn: Boolean
        if (current != null && held.`is`(current.item)) {
            active.remove(mode)
            turnedOn = false
        } else {
            active[mode] = ActiveMode(held.item, player.level().gameTime)
            turnedOn = true
        }

        if (!turnedOn && mode == DisplayMode.TORCH) darkSpots = emptyList()

        SneakSkillClient.playDing(player, if (turnedOn) 1.6f else 0.8f)
        val message = if (turnedOn) {
            Component.literal("${mode.displayName} : เปิดใช้งานแล้ว!").withStyle(ChatFormatting.GREEN)
        } else {
            Component.literal("${mode.displayName} : ปิดใช้งาน").withStyle(ChatFormatting.RED)
        }
        player.displayClientMessage(message, true)
        holdHud()
    }

    /** ขอให้หยุดเขียนทับ ActionBar ชั่วคราว (เพื่อให้ข้อความแจ้งเตือน/หลอดชาร์จอ่านทัน) */
    fun holdHud() {
        hudPauseTicks = HUD_PAUSE_TICKS
    }

    private fun tick(client: Minecraft) {
        val player = client.player
        val level = client.level
        if (player == null || level == null) {
            reset()
            return
        }

        // ทำงานเฉพาะตอนเวลาในเกมเดินจริง (ไม่ทำซ้ำตอนกดหยุดเกม)
        val now = level.gameTime
        if (now == lastProcessedTime) return
        lastProcessedTime = now

        if (active.isEmpty()) return

        // ระบบปิดอัตโนมัติ: ถือไอเท็มอื่นนานเกินกำหนด -> ปิดโหมด
        val held = player.mainHandItem
        val iterator = active.entries.iterator()
        while (iterator.hasNext()) {
            val (mode, state) = iterator.next()
            val idleTicks = now - state.lastHeldTime
            if (held.`is`(state.item) || idleTicks < 0) {
                state.lastHeldTime = now
            } else if (idleTicks > ModeSettings.IDLE_TIMEOUT_TICKS) {
                iterator.remove()
                onAutoDeactivated(player, mode)
            }
        }

        if (DisplayMode.TORCH in active) tickTorch(level, player, now) else darkSpots = emptyList()
        tickHud(level, player, now)
    }

    private fun onAutoDeactivated(player: LocalPlayer, mode: DisplayMode) {
        if (mode == DisplayMode.TORCH) darkSpots = emptyList()
        SneakSkillClient.playDing(player, 0.8f)
        player.displayClientMessage(
            Component.literal(
                "${mode.displayName} : ปิดอัตโนมัติ (ถือไอเท็มอื่นเกิน ${ModeSettings.IDLE_TIMEOUT_SECONDS} วินาที)"
            ).withStyle(ChatFormatting.RED),
            true
        )
        holdHud()
    }

    private fun reset() {
        active.clear()
        darkSpots = emptyList()
        hudPauseTicks = 0
        lastProcessedTime = Long.MIN_VALUE
    }

    // ───────────────────────── Level 1: Torch ─────────────────────────

    private fun tickTorch(level: ClientLevel, player: LocalPlayer, now: Long) {
        if (now % SCAN_INTERVAL_TICKS == 0L) {
            darkSpots = SpawnLightScanner.findDarkSpots(level, player.blockPosition())
        }
        if (now % PARTICLE_INTERVAL_TICKS == 0L) {
            for (pos in darkSpots) {
                level.addParticle(
                    MARKER_PARTICLE,
                    pos.x + 0.2 + Random.nextDouble() * 0.6,
                    pos.y + 0.05,
                    pos.z + 0.2 + Random.nextDouble() * 0.6,
                    0.0, 0.0, 0.0
                )
            }
        }
    }

    // ───────────────────── Level 2 & 3: Compass / Clock ─────────────────────

    private fun tickHud(level: ClientLevel, player: LocalPlayer, now: Long) {
        if (hudPauseTicks > 0) {
            hudPauseTicks--
            return
        }
        if (now % HUD_REFRESH_TICKS != 0L) return

        val text = buildHudText(level, player) ?: return
        player.displayClientMessage(text, true)
    }

    private fun buildHudText(level: ClientLevel, player: LocalPlayer): Component? {
        val showCoords = DisplayMode.COMPASS in active
        val showClock = DisplayMode.CLOCK in active
        if (!showCoords && !showClock) return null // Torch Mode อย่างเดียวไม่มีข้อความบน ActionBar

        val text = Component.empty()
        if (showCoords) text.append(coordinatesText(player))
        if (showCoords && showClock) text.append(Component.literal("   |   ").withStyle(ChatFormatting.DARK_GRAY))
        if (showClock) text.append(clockText(level))
        return text
    }

    private fun coordinatesText(player: LocalPlayer): Component =
        Component.literal("X: ").withStyle(ChatFormatting.GRAY)
            .append(Component.literal(player.blockX.toString()).withStyle(ChatFormatting.WHITE))
            .append(Component.literal("   Y: ").withStyle(ChatFormatting.GRAY))
            .append(Component.literal(player.blockY.toString()).withStyle(ChatFormatting.WHITE))
            .append(Component.literal("   Z: ").withStyle(ChatFormatting.GRAY))
            .append(Component.literal(player.blockZ.toString()).withStyle(ChatFormatting.WHITE))

    /**
     * เวลาในเกม 0 tick = 06:00, 6000 = 12:00, 12000 = 18:00, 18000 = 00:00
     * (ตั้งแต่ MC 26.1 เวลาของวันอยู่ที่ "นาฬิกาเริ่มต้นของมิติ" แทน Level.getDayTime())
     */
    private fun clockText(level: ClientLevel): Component {
        val dayTicks = Math.floorMod(level.getDefaultClockTime(), 24000L)
        val hour = ((dayTicks / 1000L + 6L) % 24L).toInt()
        val minute = ((dayTicks % 1000L) * 60L / 1000L).toInt()
        val digital = "${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}"

        return Component.literal("เวลา ").withStyle(ChatFormatting.GRAY)
            .append(Component.literal(digital).withStyle(ChatFormatting.YELLOW))
    }
}
