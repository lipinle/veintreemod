# Build status

Merged source based on veintreemod2, with bounded deduplicated mining queue, expected block-type checks, and world/skill checks. The original source logic and user-facing modes are retained.

**Not compiled or runtime-tested.** This execution environment has Java 21 only and no outbound access to Gradle/Fabric repositories. The supplied Minecraft/Fabric/Kotlin dependency versions and renamed API calls have not been independently verified. GitHub Actions workflow provisions Java 25 and attempts a clean build, but may reveal API/dependency errors requiring further fixes.

Upload the contents of this folder to a GitHub repository and run Actions > Build Fabric mod (Java 25) > Run workflow. A JAR artifact is produced only if the build passes.
