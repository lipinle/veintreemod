package com.example.veintreemod

import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items

/**
 * โหมดแสดงผลฝั่งไคลเอนต์ — เปิดด้วยการกดย่อ 10 ครั้งขณะถือไอเท็มที่ตรงกัน
 */
enum class DisplayMode(val displayName: String) {
    TORCH("Torch Mode"),
    COMPASS("Compass Mode"),
    CLOCK("Clock Mode");

    /** ไอเท็มนี้เปิดโหมดนี้ได้หรือไม่ */
    fun accepts(stack: ItemStack): Boolean = when (this) {
        TORCH -> stack.`is`(Items.TORCH) || stack.`is`(Items.SOUL_TORCH)
        COMPASS -> stack.`is`(Items.COMPASS)
        CLOCK -> stack.`is`(Items.CLOCK)
    }

    companion object {
        fun forItem(stack: ItemStack): DisplayMode? = entries.firstOrNull { it.accepts(stack) }
    }
}
