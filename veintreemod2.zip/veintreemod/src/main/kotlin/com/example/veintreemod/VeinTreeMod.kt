package com.example.veintreemod

import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer

object VeinTreeMod : ModInitializer {
    override fun onInitialize() {
        // 1. ลงทะเบียน Packet C2S
        PayloadTypeRegistry.serverboundPlay().register(ActivateSkillPayload.ID, ActivateSkillPayload.CODEC)

        ServerPlayNetworking.registerGlobalReceiver(ActivateSkillPayload.ID) { _, context ->
            context.server().execute {
                ProgressiveMinerManager.toggleSkillForHeldItem(context.player())
            }
        }

        // 2. ตรวจจับเมื่อผู้เล่นขุดบล็อกแตก
        PlayerBlockBreakEvents.AFTER.register { level, player, pos, state, _ ->
            if (level is ServerLevel && player is ServerPlayer) {
                ProgressiveMinerManager.onBlockBrokenByPlayer(player, level, pos, state)
            }
        }

        // 3. ประมวลผลการขุดต่อเนื่องทีละบล็อกในทุก Tick
        ServerTickEvents.END_SERVER_TICK.register { server ->
            ProgressiveMinerManager.tick(server)
        }
    }
}
