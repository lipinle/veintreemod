package com.example.veintreemod

import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.tags.BlockTags
import net.minecraft.world.level.Level
import net.minecraft.world.level.LightLayer
import net.minecraft.world.level.block.state.BlockState

/**
 * หาตำแหน่งรอบตัวผู้เล่นที่ "แสงต่ำพอให้มอนสเตอร์เกิดได้" โดยนับเฉพาะแสงจากบล็อก
 * (ไม่นับแสงอาทิตย์) จึงแสดงผลเหมือนกันทั้งกลางวันและกลางคืน
 */
object SpawnLightScanner {
    private const val RADIUS = 8           // รัศมีแนวราบ (บล็อก)
    private const val VERTICAL_RANGE = 4   // ช่วงสูง/ต่ำจากตัวผู้เล่น (บล็อก)
    private const val MAX_SPOTS = 160      // จำกัดจำนวนจุดเพื่อไม่ให้อนุภาคเยอะเกินไป

    fun findDarkSpots(level: ClientLevel, center: BlockPos): List<BlockPos> {
        val lightLimit = blockLightLimit(level)
        val radiusSq = RADIUS * RADIUS
        val cursor = BlockPos.MutableBlockPos()
        val spots = ArrayList<BlockPos>()

        for (dx in -RADIUS..RADIUS) {
            for (dz in -RADIUS..RADIUS) {
                if (dx * dx + dz * dz > radiusSq) continue
                for (dy in -VERTICAL_RANGE..VERTICAL_RANGE) {
                    cursor.set(center.x + dx, center.y + dy, center.z + dz)
                    if (canMonsterSpawnAt(level, cursor, lightLimit)) {
                        spots.add(cursor.immutable())
                    }
                }
            }
        }

        // ถ้ามีเยอะเกินไป เลือกจุดที่ใกล้ผู้เล่นที่สุดก่อน
        spots.sortBy { it.distSqr(center) }
        return spots.take(MAX_SPOTS)
    }

    /**
     * ค่าแสงบล็อกสูงสุดที่มอนสเตอร์ยังเกิดได้:
     * - Overworld / End : ต้องเป็น 0 (กฎตั้งแต่ 1.18)
     * - Nether          : เกิดได้เมื่อแสง <= 7
     */
    private fun blockLightLimit(level: ClientLevel): Int =
        if (level.dimension() == Level.NETHER) 7 else 0

    private fun canMonsterSpawnAt(level: ClientLevel, pos: BlockPos, lightLimit: Int): Boolean {
        // 1) แสงจากบล็อกเท่านั้น (ตัดแสงอาทิตย์ออก)
        if (level.getBrightness(LightLayer.BLOCK, pos) > lightLimit) return false

        // 2) ต้องมีที่ว่างพอให้มอนสเตอร์ยืน (ระดับเท้า + ระดับหัว)
        val feetState = level.getBlockState(pos)
        if (!isOpenSpace(level, pos, feetState)) return false
        if (feetState.`is`(BlockTags.PREVENT_MOB_SPAWNING_INSIDE)) return false // เช่น ราง

        val headPos = pos.above()
        if (!isOpenSpace(level, headPos, level.getBlockState(headPos))) return false

        // 3) พื้นด้านล่างต้องแข็งพอให้ยืนได้
        val floorPos = pos.below()
        return level.getBlockState(floorPos).isFaceSturdy(level, floorPos, Direction.UP)
    }

    private fun isOpenSpace(level: ClientLevel, pos: BlockPos, state: BlockState): Boolean =
        state.getCollisionShape(level, pos).isEmpty && state.fluidState.isEmpty
}
