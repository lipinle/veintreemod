package com.example.veintreemod

import net.minecraft.network.RegistryFriendlyByteBuf
import net.minecraft.network.codec.StreamCodec
import net.minecraft.network.protocol.common.custom.CustomPacketPayload
import net.minecraft.resources.Identifier

data object ActivateSkillPayload : CustomPacketPayload {
    val ID = CustomPacketPayload.Type<ActivateSkillPayload>(
        Identifier.fromNamespaceAndPath("veintreemod", "activate_skill")
    )

    val CODEC: StreamCodec<RegistryFriendlyByteBuf, ActivateSkillPayload> =
        StreamCodec.unit(ActivateSkillPayload)

    override fun type(): CustomPacketPayload.Type<out CustomPacketPayload> = ID
}
