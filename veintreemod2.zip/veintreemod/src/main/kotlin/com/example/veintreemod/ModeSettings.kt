package com.example.veintreemod

/**
 * ค่าตั้งร่วมของ "โหมดพิเศษ" ทุกโหมด (Veinminer, Tree Capitator, Torch, Compass, Clock)
 */
object ModeSettings {
    /** ถ้าผู้เล่นถือไอเท็มอื่น (ที่ไม่ใช่ไอเท็มที่เปิดโหมดไว้) นานเกินกี่วินาที โหมดจะปิดเอง */
    const val IDLE_TIMEOUT_SECONDS = 10

    /** 1 วินาที = 20 tick */
    const val IDLE_TIMEOUT_TICKS = IDLE_TIMEOUT_SECONDS * 20
}
